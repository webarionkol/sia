import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ManufacturePage } from './manufacture';

@NgModule({
  declarations: [
    ManufacturePage,
  ],
  imports: [
    IonicPageModule.forChild(ManufacturePage),
  ],
})
export class ManufacturePageModule {}
