export const sender_id = '428473323891';
export const oneSignalAppId = 'dbc378f4-c6a9-44e2-ac35-0138310d7859';